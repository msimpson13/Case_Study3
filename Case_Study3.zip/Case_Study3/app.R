#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

wineList <- c("Red" = "Red", "white" = "White", "Rose" = "Rose", "Sparkling" = "Sparkling")

library(cluster)
library(cluster.datasets)
library(ggvis)
library(tidyverse)  # data manipulation
library(factoextra) # clustering algorithms & visualization

wine.df = readRDS(file="Wine.Rda")
wine.df = subset(wine.df,  Year != "N.V.", select=Name:type) ## removes wine data that did not have a year 
year_num <- as.numeric(wine.df$Year) # converts the year into a numeric value
wine.df$Year <- year_num # adds the numeric back into the data set 
best_year <- wine.df # keeps a table of the best years

library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(
   

    # Application title
    titlePanel("Wine Vintage K-Mean Clustering"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            sliderInput("Year", "Vintage (Year)", min = 1961, max = 2020, value = c(2000, 2020),  sep = ""),
            sliderInput("Price", "Price", min = 0, max = 500, value = c(0, 50),  sep = ",", pre="$"),
            sliderInput("numRating", "Number Of Ratings", min = 0, max = 3500, value = c(50, 3500),  sep = ","),
            selectInput("type", "Wine Type:", wineList,  selected = "Red", multiple = TRUE),
            sliderInput("centers", "Number of Centers:", min = 1, max = 25, value = 6)
            
        ),
        
   
        # Show a plot of the generated distribution
        mainPanel(
           tabsetPanel(
             tabPanel("Plot", plotOutput("distPlot")), 
             tabPanel("SSE Num Cluster", plotOutput("num_cluster")),
             tabPanel("Table", dataTableOutput("table")),
             tabPanel("Cluster Info", dataTableOutput("culster_info")),
             tabPanel("Best Years", dataTableOutput("best"))
           )
        )
    )
)


# Define server logic required to draw a histogram
server <- function(input, output) {
  
  # looks at the users input and filters the data accordingly 
  dataInput <- reactive({
    # The flowing lines listen to the various filters on the data to exclude certain data. 
    
    ## Filters for Wine Year (Vintage)
    wine.df = subset(wine.df,  Year >= input$Year[1] , select=Name:type) ## removes wine data that has a vintage greater than the min 
    wine.df = subset(wine.df,  Year <= input$Year[2] , select=Name:type) ## removes wine data that has a vintage greater than the max
    
    ## Filters for Price
    wine.df = subset(wine.df,  Price >= input$Price[1] , select=Name:type) ## removes wine data that has a price greater than the min 
    wine.df = subset(wine.df,  Price <= input$Price[2] , select=Name:type) ## removes wine data that has a price greater than the max
    
    
    ## filters the wine based on the types of wine
    wineList <-  input$type
     wine.df <- switch( ## switch statment looks at how many elements was selected and does 
      length(wineList), 
      subset(wine.df,  type == wineList[1] , select=Name:type),
      subset(wine.df,  type == wineList[1] |  type == wineList[2] , select=Name:type),
      subset(wine.df,  type == wineList[1] |  type == wineList[2] | type == wineList[3], select=Name:type),
      subset(wine.df,  type == wineList[1] |  type == wineList[2] | type == wineList[3] | type == wineList[3] , select=Name:type),
    )
    
    ## Filters for Number of Ratings 
    wine.df = subset(wine.df,  NumberOfRatings >= input$numRating[1] , select=Name:type) ## removes wine data that has a price greater than the min 
    wine.df = subset(wine.df,  NumberOfRatings <= input$numRating[2] , select=Name:type) ## removes wine data that has a price greater than the max
    

    # ## Creates a cluster
    # wine_year.df <- wine.df[c("Rating","Year")]  #Creates a data frame of just year and rating
    # clusters_year = kmeans(wine_year.df, input$centers)
    # wine.df$Cluster = clusters_year$cluster

  })
  
  clusterInput <- reactive({
    
    wine.df <- dataInput()
    wine_year.df <- wine.df[c("Rating","Year")]
    clusters_year = kmeans(wine_year.df, input$centers)
    wine.df$Cluster_Year = clusters_year$cluster

    # breaks down the cluster data into useful information

    # Creates vectors for the data to fill in
    country <- c()
    year_start <- c()
    year_end <- c()
    year_delta <- c()
    avg_rating <- c()
    avg_price <- c()
    cluster_num <- c()

    for (i in 1:input$centers) { #for loop that iterates over all the clusters in the data frame
      cluster_data <- subset(wine.df,  Cluster_Year == i , select=Name:Cluster_Year) # gets the subset of the data for a particular cluster
      u_country <- unique(cluster_data[c("Country")]) # gets a list of country for a particular cluster

      for (val in u_country$Country) { # loop that iterates over the list of country collecting data

        val_cluster <- i

        df <- subset(wine.df,  Cluster_Year == val_cluster & Country == val, select=Name:Cluster_Year) # selects the data to calculate

        # puts the basic information in the vector
        country <- append(country, val) # adds country to the vector
        cluster_num <- append(cluster_num, i) # adds cluster number to the vector

        # Puts the average information in the vector
        avg_rating <- append(avg_rating, mean(df$Rating)) # calculates the avg rating and adds to vector
        avg_price <- append(avg_price, mean(df$Price)) # calculates the avg price and adds to vector

        df$Year <- as.numeric(df$Year) # converts the year to a numeric

        # calculates information about the year
        min_year <- min(df$Year) # calculates the min year of the selected data
        max_year <- max(df$Year) # calculates the max year of the selected data
        delta <- max_year - min_year # calculates the delta between the two years

        # adds the data to the vector
        year_start <- append(year_start, min_year)
        year_end <- append(year_end, max_year)
        year_delta <- append(year_delta, delta)
      }

    }

    cluster_info <- data.frame(country, year_start, year_end, year_delta, avg_rating, avg_price, cluster_num )
     cluster_info

  })
  
    ## Creates the plot of the number of clusters 
    output$num_cluster <- renderPlot({
      set.seed(123)
      #Creates a data frame of just year and rating 
      wine_year.df <- dataInput()[c("Rating","Year")] 
      
      # function to compute total within-cluster sum of square 
      wss <- function(k) {
        kmeans( wine_year.df, k, nstart = 10 )$tot.withinss
      }
      
      # Compute and plot wss for k = 1 to k = 15
      k.values <- 1:15
      
      # extract wss for 2-15 clusters
      wss_values <- map_dbl(k.values, wss)
      
      plot(k.values, wss_values,
           type="b", pch = 19, frame = FALSE, 
           xlab="Number of clusters K",
           ylab="Total within-clusters sum of squares")
    
      
    })
   
    # Renders the cluster plot 
    output$distPlot <- renderPlot({
        
         #Creates a data frame of just year and rating 
        wine_year.df <- dataInput()[c("Rating","Year")] 
        # Creates the cluster
        clusters_year = kmeans(wine_year.df, input$centers) ## creates the cluster based on the user input of number of centers 
        # draw the cluster Polt with specific number of centers. 
        clusplot(wine_year.df, clusters_year$cluster, color=T, shade=F,labels=0,lines=0, main='k-Means Cluster Analysis Year')
    })
    
    ## Creates a table of the selected data 
    output$table <-  renderDataTable({
      
      wine.df <- dataInput()
      wine_year.df <- wine.df[c("Rating","Year")] 
      clusters_year = kmeans(wine_year.df, input$centers)
      wine.df$Cluster_Year = clusters_year$cluster
      wine.df
      })
    
    ## Creates a summary of the data 
    output$culster_info <-  renderDataTable({

      clusterInput()
  })
    
    
    output$best <-  renderDataTable({
      wine.df <-  clusterInput()
      
      country <- c()
      year_start <- c()
      year_end <- c()
      year_delta <- c()
      avg_rating <- c()
      avg_price <- c()
      cluster_num <- c()
    
      u_country <- unique(clusterInput()[c("country")]) # gets a list of country for a particular cluster
      ## finds the best cluster for each country
      for(val2 in u_country$country){
        single_country <- subset(clusterInput(),  country == val2, select=country:cluster_num) # selects the data to calculate
        single_year <- single_country[which.max(single_country$avg_rating),]
        
        country <- append(country, single_year$country) 
        year_start <- append(year_start, single_year$year_start) 
        year_end <-append(year_end, single_year$year_end) 
        year_delta <- append(year_delta, single_year$year_delta) 
        avg_rating <-  append(avg_rating, single_year$avg_rating) 
        avg_price <- append(avg_price, single_year$avg_price) 
        cluster_num <- append(cluster_num, single_year$cluster_num) 
        
      }
     
      cluster_info <- data.frame(country, year_start, year_end, year_delta, avg_rating, avg_price, cluster_num )
      cluster_info
      
    })
    
    
 
    
    
    
}

# Run the application


shinyApp(ui = ui, server = server, options = list(display.mode = 'showcase'))

